import React from 'react'
import PostSlider from '../../Slider/PostSlider'

export default function PostSectionStyle5({data, sectionTitleUp, sectionTitle}) {
  return (
    <PostSlider data={data} sectionTitleUp={sectionTitleUp} sectionTitle={sectionTitle} />
  )
}
