import React from 'react'
import ServiceSlider from '../../Slider/ServiceSlider'

export default function ServiceSectionStyle2({data, sectionTitleUp, sectionTitle}) {
  return (
    <ServiceSlider data={data} sectionTitleUp={sectionTitleUp} sectionTitle={sectionTitle} />
  )
}
