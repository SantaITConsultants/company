import React from 'react'
import ServiceSliderStyle2 from '../../Slider/ServiceSliderStyle2'

export default function ServiceSectionStyle3({data, sectionTitleUp, sectionTitle}) {
  return (
    <ServiceSliderStyle2 data={data} sectionTitleUp={sectionTitleUp} sectionTitle={sectionTitle} />
  )
}
