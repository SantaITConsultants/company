export const pageTitle = title => {
  return (document.title =
    title + ' | Bizmax - Corporate And Consulting Business Template');
};
